package org.androidtown.lab6_1;

import android.os.Environment;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;

public class MainActivity extends AppCompatActivity {
    private EditText txtdata;
    private Button btnWriteSDFile;
    private Button bttnRead;
    private Button btnClearScreen;
    private Button btnFinish;
    private String mySdPath;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mySdPath = Environment.getExternalStorageDirectory().getAbsolutePath();
        final File directory = new File(mySdPath + "");
        directory.mkdirs();
        txtdata = (EditText) findViewById(R.id.txtData);
        txtdata.setHint("Enter some lines of data here...");
        btnWriteSDFile = (Button) findViewById(R.id.btnWriteSDFile);
        btnWriteSDFile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    File myFile = new File(directory, "mysdfile.txt");
                    OutputStreamWriter myOutwriter = new OutputStreamWriter(
                            new FileOutputStream(myFile));
                    myOutwriter.append(txtdata.getText());
                    myOutwriter.close();
                    Toast.makeText(getApplicationContext(),
                            "Done writing Sd 'mysdfile.txt'", Toast.LENGTH_SHORT).show();
                } catch (Exception e) {
                    Toast.makeText(getApplicationContext(), e.getMessage(), Toast.LENGTH_SHORT).show();
                }
            }
        });
        bttnRead = (Button) findViewById(R.id.btnReadSDFile);
        bttnRead.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    BufferedReader myReader = new BufferedReader(
                            new InputStreamReader(
                                    new FileInputStream(new File(directory, "mysdfile.txt"))));
                    String ab="";
                    String aBuffer = "";
                    while ((ab = myReader.readLine()) != null) {
                        aBuffer += ab + "\n";
                    }
                    txtdata.setText(aBuffer);
                    myReader.close();
                    Toast.makeText(getApplicationContext(),
                            "Done reading SD 'mysdfile.txt'", Toast.LENGTH_SHORT).show();
                } catch (Exception e) {
                    Toast.makeText(getApplicationContext(), e.getMessage(),
                            Toast.LENGTH_SHORT).show();
                }
            }
        });
        btnClearScreen=(Button)findViewById(R.id.btnClearScreen);
        btnClearScreen.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                txtdata.setText("");
            }
        });
        btnFinish=(Button)findViewById(R.id.btnFinish);
        btnFinish.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                finish();
            }
        });
    }
}
