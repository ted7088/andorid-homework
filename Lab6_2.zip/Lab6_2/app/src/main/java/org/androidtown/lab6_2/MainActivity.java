package org.androidtown.lab6_2;

import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
public class MainActivity extends AppCompatActivity {

    Button store, call, initialization;
    String username, password;
    EditText userID, userPassword;
    SharedPreferences pref1;
    SharedPreferences.Editor toEdit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        store = findViewById(R.id.button2);
        call = findViewById(R.id.button1);
        initialization = findViewById(R.id.button3);
        userID = findViewById(R.id.edit2);
        userPassword = findViewById(R.id.edit1);
        store.setOnClickListener(new Button.OnClickListener() {
            @Override
            public void onClick(View view) {
                username = userID.getText().toString();
                password = userPassword.getText().toString();
                sharedPreferences();
                Toast.makeText(getApplicationContext(), "Data is saved", Toast.LENGTH_SHORT).show();
            }
        });
        initialization.setOnClickListener(new Button.OnClickListener() {
            @Override
            public void onClick(View view) {
                userID.setText("");
                userPassword.setText("");
            }
        });
        call.setOnClickListener(new Button.OnClickListener() {
            @Override
            public void onClick(View view) {
                applySharedPreference();

            }
        });

    }

    public void sharedPreferences() {
        pref1 = getSharedPreferences("Login Credentials", MODE_PRIVATE);
        toEdit = pref1.edit();
        toEdit.putString("Username", username);
        toEdit.putString("Password", password);
        toEdit.commit();
    }

    public void applySharedPreference() {
        pref1 = getSharedPreferences("Login Credentials", MODE_PRIVATE);
        if (pref1 != null && pref1.contains("Username")) {
            String name = pref1.getString("Username", "noname");
            String pw = pref1.getString("Password", "nopassword");
            userID.setText(name);
            userPassword.setText(pw);
        }
    }
}

