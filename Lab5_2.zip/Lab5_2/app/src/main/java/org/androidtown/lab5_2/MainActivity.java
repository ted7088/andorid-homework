package org.androidtown.lab5_2;

        import android.os.AsyncTask;
        import android.support.v7.app.AppCompatActivity;
        import android.os.Bundle;
        import android.view.View;
        import android.widget.Button;
        import android.widget.EditText;
        import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    EditText edt;
    Button btn;
    TextView calculate,result;
    int num;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        init();
    }

    public void init(){
        edt=(EditText)findViewById(R.id.edt1);
        btn=(Button)findViewById(R.id.btn1);
        calculate=(TextView)findViewById(R.id.tV1);
        result=(TextView)findViewById(R.id.tV2);

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                num=Integer.parseInt(edt.getText().toString());
                new factorial().execute();
            }
        });
    }

    public class factorial extends AsyncTask<Void, Integer, Void> {

        String msg="";
        int fac=1;

        @Override
        protected void onPreExecute(){
            try{
                int numsTrue=num;
            }catch(Exception e){
                Thread.interrupted();
            }
        }
        @Override
        protected Void doInBackground(Void... params){
            for(int i=0;i<num;i++){
                try{
                    Thread.sleep(500);
                    fac=fac*(num-i);
                    publishProgress(num-i);
                }catch(Exception e){}
            }
            return null;
        }
        @Override
        protected void onProgressUpdate(Integer... values){
            msg+=Integer.toString(values[0].intValue())+" ";
            calculate.setText(msg);  //set the msg
        }
        @Override
        protected void onPostExecute(Void aVoid){
            result.setText("= "+fac);
        }
    }
}
